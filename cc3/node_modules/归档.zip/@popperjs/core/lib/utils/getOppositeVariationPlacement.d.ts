import type { Placement } from "../enums";
export default function getOppositeVariationPlacement(placement: Placement): Placement;
